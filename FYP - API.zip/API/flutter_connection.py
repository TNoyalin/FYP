from flask import Flask, request, jsonify
import numpy as np
import pandas as pd
import csv
import re
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
app = Flask(__name__)
from sklearn.feature_extraction.text import CountVectorizer
import pickle
import joblib
@app.route('/', methods = ['GET'])
def index():
    text = str(request.args['query'])
    data=[text]
    text=["Review"]
    with open('example.csv', 'w') as file:
        writer = csv.writer(file)
        writer.writerow(text)
        writer.writerow(data)
    dataset=pd.read_csv('example.csv', delimiter = '\t', quoting = 3)
    dataset.head()
    
    ps=PorterStemmer()
    all_stopwords=stopwords.words('english')
    all_stopwords.remove('not')
    corpus=[]
    for i in range(0,1):
        review=re.sub('[^a-zA-Z]',' ',dataset['Review'][i])
        review=review.lower()
        review=review.split()
        review=[ps.stem(word) for word in review if not word in set(all_stopwords)]
        review=' '.join(review)
        corpus.append(review)
        
    
    cvFile='D:/Acadamic/FYP/sentiment_analysis-main/bow sentiment model.pkl'
    cv=pickle.load(open(cvFile,"rb"))
    X_fresh=cv.transform(corpus).toarray()
    X_fresh.shape
     
    classifier=joblib.load('D:/Acadamic/FYP/sentiment_analysis-main/classifier sentiment model')
    y_pred=classifier.predict(X_fresh)
    print(y_pred)
    print(len(y_pred))
    d={}
    if (y_pred[0] == 1):
        d='A calm mind is like a source of energy. It helps you become powerful. So, head towards your future success with a focused and professional mindset🤗🤗'
        return d
    else:
        d='Even though we can\'t control the wind, we can change how our sails are set. So, keep trying and never give up—success comes from persistence.'
        return d

if __name__ =="__main__":
    app.run()